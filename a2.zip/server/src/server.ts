import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config({ path: "../.env" });

const app = express();
const PORT = process.env.SERVER_PORT || 3001;

app.use(cors());
app.use(express.json());

interface TokenRequest {
  code: string;
}

interface TokenResponse {
  access_token: string;
}

app.post("/api/token", async (req, res) => {
  const { code } = req.body as TokenRequest;

  const params = new URLSearchParams({
    client_id: process.env.VITE_DISCORD_CLIENT_ID!,
    client_secret: process.env.DISCORD_CLIENT_SECRET!,
    grant_type: "authorization_code",
    code,
  });

  const response = await fetch("https://discord.com/api/oauth2/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: params,
  });

  const data = (await response.json()) as TokenResponse;
  res.json({ access_token: data.access_token });
});

app.listen(PORT, () => {
  console.log(`Server listening at http://localhost:${PORT}`);
});
